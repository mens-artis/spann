Spanners
========

This is a visualization of the concept of spanner in computational geometry. 