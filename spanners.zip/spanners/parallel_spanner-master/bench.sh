benchme/benchme ../dataset/us_cities.csv 1.3 benchme/libbenchme_greedy.so benchme/libbenchme_parallel_greedy.so
