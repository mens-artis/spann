# PRPA
neato result.gv -n -Tpng -o sample.png && feh sample.png
