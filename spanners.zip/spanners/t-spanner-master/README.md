# [WIP] T-spanner

This is a school assignment.
Note: OpenCL kernel is just a dummy kernel for now.

## Required:

- [X] Greedy T-spanner
- [X] C++ // T-spanner algorithm

## Roadmap:

- [X] Greedy T-spanner
- [ ] C++ // Using Well seperated pair decomposition
- [ ] // algo using OpenCL
- [X] Python bindings
