#pragma once

#include "types.h"

int greedy_linear(struct graph_t *graph, struct graph_t *output, float t);
