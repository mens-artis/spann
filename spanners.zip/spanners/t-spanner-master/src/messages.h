#pragma once

#define MSG_USAGE_PARAMS " <Input.graph> <Output.dot>"
#define MSG_USAGE_INTRO "Usage: "
