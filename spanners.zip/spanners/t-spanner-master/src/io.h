#pragma once

int load_graph(const char* path, struct graph_t *graph);
int output_graph(struct graph_t *graph, const char *path);
