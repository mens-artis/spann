# Theta-Graph
The handdraw-figure report including more figures' details (the algorithm descriptions are more detailed), the other report is more good looking... 

For the report part, I wrote the history for spanners, different proofs toward a better upperbound for spanning ratio, and the O(nlogn) time complexity plane sweeping algorithm for building Theta Graph, and the facts for theta 4,5,6.

For the experiment part, I tested the different upperbounds for spanning ratios in some special cases of paper “Towards Tight Bounds on Theta-Graphs”.
